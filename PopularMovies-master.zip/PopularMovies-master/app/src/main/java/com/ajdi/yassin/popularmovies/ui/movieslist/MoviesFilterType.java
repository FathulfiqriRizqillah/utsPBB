package com.ajdi.yassin.popularmovies.ui.movieslist;

/**
 * @author Yassin Ajdi.
 */
public enum MoviesFilterType {
    POPULAR,
    TOP_RATED,
    NOW_PLAYING
}
