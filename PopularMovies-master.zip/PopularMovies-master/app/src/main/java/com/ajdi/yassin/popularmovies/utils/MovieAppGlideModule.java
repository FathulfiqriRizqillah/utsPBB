package com.ajdi.yassin.popularmovies.utils;

import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

/**
 * @author Yassin Ajdi.
 */
@GlideModule
public class MovieAppGlideModule extends AppGlideModule {
}
